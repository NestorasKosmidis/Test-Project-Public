<?php /* Template Name: Homepage-Template */ ?>

<?php get_header(); ?>

<main class="site-content">

    <section class="intro-wrapper">
        <div class="intro-wrap">
            <h1 class="hero-title show-on-scroll slide-up"><?php the_field('intro_headline');?></h1>
            <span class="hero-text show-on-scroll slide-up"><?php the_field('intro_text');?></span>
            <a class="hero-button show-on-scroll slide-up" href="#"><?php the_field('intro_button');?></a>
        </div>
        <div class="image-wrap">
            <?php $image = get_field('intro_image');
            if ( !empty($image) ): ?>
                <img class="hero-image" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
            <?php endif; ?>
            <img class="shape-small" src="<?php echo get_stylesheet_directory_uri();?>/assets/images/shape-small.png" alt="review">
            <img class="shape-large" src="<?php echo get_stylesheet_directory_uri();?>/assets/images/shape-large.png" alt="review">

        </div>
    </section>

    <section class="brands-section">
        <div class="loop-slider">
            <div class="slide-track">
                <?php 
                for ($i = 1; $i <= 6; $i++) {
                    $brand = get_field('brand_' . $i);
                    if ($brand) : ?>
                        <div class="loop-slide">
                            <img src="<?php echo esc_url($brand['url']); ?>" alt="<?php echo esc_attr($brand['alt']); ?>" />
                        </div>
                    <?php endif; 
                }
                ?>
                <?php 
                for ($i = 1; $i <= 6; $i++) {
                    $brand = get_field('brand_' . $i);
                    if ($brand) : ?>
                        <div class="loop-slide">
                            <img src="<?php echo esc_url($brand['url']); ?>" alt="<?php echo esc_attr($brand['alt']); ?>" />
                        </div>
                    <?php endif; 
                }
                ?>
            </div>
        </div>
    </section>


    <section class="arrivals-section">
        <div class="intro-wrap">
            <h2 class="arrivals-main-title show-on-scroll slide-up"><?php _e('NEW ARRIVALS');?></h2>
        </div>
        <div class="arrivals-wrapper">
            <div class="arrival">
                <div class="image-wrap">
                    <?php $image = get_field('arrival_1');
                    if ( !empty($image) ): ?>
                        <img class="arrival-image" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
                    <?php endif; ?>
                    <span class="arrival-title"><?php _e('T-shirt with Tape Details');?></span>
                    <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/4.5-5.png" alt="review" class="product-review">
                    <span class="arrival-price"><?php _e('$120');?></span>   
                </div>
            </div>

            <div class="arrival">
                <div class="image-wrap">
                    <?php $image = get_field('arrival_2');
                    if ( !empty($image) ): ?>
                        <img class="arrival-image" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
                    <?php endif; ?>
                    <span class="arrival-title"><?php _e('Skinny Fit Jeans');?></span>
                    <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/3.5-5.png" alt="review" class="product-review">
                    <div class="prices-wrap">
                        <span class="arrival-price"><?php _e('$240');?></span><span class="old-price"><?php _e('$260');?></span><span class="discount"><?php _e('-20%');?></span>
                    </div>
                </div>
            </div>

            <div class="arrival">
                <div class="image-wrap">
                    <?php $image = get_field('arrival_3');
                    if ( !empty($image) ): ?>
                        <img class="arrival-image" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
                    <?php endif; ?>
                    <span class="arrival-title"><?php _e('Checkered Shirt');?></span>
                    <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/4.5-5.png" alt="review" class="product-review">
                    <span class="arrival-price"><?php _e('$180');?></span>   
                </div>
            </div>

            <div class="arrival">
                <div class="image-wrap">
                    <?php $image = get_field('arrival_4');
                    if ( !empty($image) ): ?>
                        <img class="arrival-image" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
                    <?php endif; ?>
                    <span class="arrival-title"><?php _e('Sleeve Striped T-shirt');?></span>
                    <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/4.5-5.png" alt="review" class="product-review">
                    <div class="prices-wrap">
                        <span class="arrival-price"><?php _e('$130');?></span><span class="old-price"><?php _e('$160');?></span><span class="discount"><?php _e('-30%');?></span>          
                    </div>
                </div>
            </div>
        </div>
    </section>
           
    <a class="viewallbtn" href="#"><?php _e('View All'); ?></a>


    <section class="categories show-on-scroll slide-up">
        <h3 class="categories-main-title"><?php _e('Browse By Dress Style');?></h3>
        <div class="categories-wrapper">
            <div class="row">
                <div class="casual">
                    <?php $image = get_field('casual_image');
                    if ( !empty($image) ): ?>
                        <img class="category-image" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
                    <?php endif; ?>  
                    <span class="category-title"><?php  _e('Casual'); ?></span>  
                </div>
                <div class="formal">
                    <?php $image = get_field('formal_image');
                    if ( !empty($image) ): ?>
                        <img class="category-image" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
                    <?php endif; ?>  
                    <span class="category-title"><?php  _e('Formal'); ?></span>   
                </div>
            </div>
            <div class="row">
                <div class="party">
                    <?php $image = get_field('party_image');
                    if ( !empty($image) ): ?>
                        <img class="category-image" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
                    <?php endif; ?> 
                    <span class="category-title"><?php  _e('Party'); ?></span>    
                </div>
                <div class="gym">
                    <?php $image = get_field('gym_image');
                    if ( !empty($image) ): ?>
                        <img class="category-image" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
                    <?php endif; ?> 
                    <span class="category-title"><?php  _e('Gym'); ?></span>    
                </div>
            </div>
        </div>               
    </section>


    <section class="reviews">

        <h4 class="reviews-main-title show-on-scroll slide-up"><?php _e('Our Happy Customers');?></h4>
        
        <div class="slider-arrows">
            <button class="custom-prev-arrow"><span class="icon-left"></span></button>
            <button class="custom-next-arrow"><span class="icon-right"></span></button>
        </div>

        <div class="reviews-wrapper">

            <div class="single-review">
                <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/rating.png" alt="review" class="product-review">
                <span class="name"><?php the_field('name_1');?><img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/check.png" alt="review" class="product-review"></span></span>
                <span class="review-text"><?php the_field('review_1');?></span>
            </div>
            <div class="single-review">
                <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/rating.png" alt="review" class="product-review">
                <span class="name"><?php the_field('name_2');?><img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/check.png" alt="review" class="product-review"></span></span>
                <span class="review-text"><?php the_field('review_2');?></span>
            </div>
            <div class="single-review">
                <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/rating.png" alt="review" class="product-review">
                <span class="name"><?php the_field('name_3');?><img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/check.png" alt="review" class="product-review"></span></span>
                <span class="review-text"><?php the_field('review_3');?></span>
            </div>
            <div class="single-review">
                <img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/rating.png" alt="review" class="product-review">
                <span class="name"><?php the_field('name_4');?><img src="<?php echo get_stylesheet_directory_uri();?>/assets/images/check.png" alt="review" class="product-review"></span>
                <span class="review-text"><?php the_field('review_4');?></span>
            </div>


        </div>

    </section>

</main>

<?php get_footer(); ?>
