jQuery(document).ready(function($) {
    $('.reviews-wrapper').slick({
        slidesToShow: 2.88,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1000,
        dots: false,
        arrows: false, 
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            }
        ]
    });

    $('.custom-prev-arrow').click(function() {
        $('.reviews-wrapper').slick('slickPrev');
    });

    $('.custom-next-arrow').click(function() {
        $('.reviews-wrapper').slick('slickNext');
    });
});


jQuery(document).ready(function($) {
    function initializeSlick() {
        // Έλεγχος αν το slider έχει ήδη ενεργοποιηθεί
        if ($(window).width() < 768) {
            if (!$('.arrivals-wrapper').hasClass('slick-initialized')) {
                $('.arrivals-wrapper').slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    autoplay: true,
                    autoplaySpeed: 3000,
                    dots: false,
                    arrows: false,
                    infinite: true,
                    mobileFirst: true
                });
            }
        } else {
            if ($('.arrivals-wrapper').hasClass('slick-initialized')) {
                $('.arrivals-wrapper').slick('unslick');
            }
        }
    }

    initializeSlick();

    $(window).resize(function() {
        initializeSlick();
    });
});
