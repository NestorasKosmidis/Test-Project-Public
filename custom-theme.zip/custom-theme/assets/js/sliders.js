//Homepage Slider
var heroSlider = new Swiper(".single-slider-wrapper", {
    effect: "fade",
    loop: true,
    // autoplay: {
    //     delay: 4000,
    //     disableOnInteraction: false,
    // },
});

