jQuery(document).ready(function() {
	jQuery('.scroll-div').click(function() {
		var scrollId = jQuery(this).data('scrollid');
		if (!scrollId)
			return false;
		var scrollpos = jQuery('#' + scrollId).offset().top;
		var headerHeight = jQuery('.custom-header').outerHeight();
		scrollpos = scrollpos - (headerHeight + 0);
		jQuery('html,body').animate({
			scrollTop: (scrollpos)
		}, 1000, function() { });
	})
})



jQuery(document).ready(function($) {
    $('.burger-menu').click(function() {
        $('.header-menu-wrap').toggleClass('active');
    });

    $(document).mouseup(function(e) {
        var menu = $('.header-menu-wrap.active');
        if (!menu.is(e.target) && menu.has(e.target).length === 0) {
            menu.removeClass('active');
        }
    });
});


jQuery(document).ready(function($) {
    $('.close-popup').click(function() {
        $('.pop_up_offer').addClass('hide');
    });
});


// Detect request animation frame
var scroll = window.requestAnimationFrame ||
    // IE Fallback
    function(callback) { window.setTimeout(callback, 1000 / 60) };

var elementsToShow = document.querySelectorAll('.show-on-scroll');

function loop() {
    var scrollFromTop = window.pageYOffset || document.documentElement.scrollTop;
    var i;

	if (elementsToShow.length) {
        for (i = 0; i < elementsToShow.length; i++) {
            if (isElementPartiallyInViewport(elementsToShow[i])) {
                elementsToShow[i].classList.remove('slide-right');
                elementsToShow[i].classList.remove('slide-up');
                elementsToShow[i].classList.remove('slide-down');
                elementsToShow[i].classList.remove('slide-left');
            }
        }
    }

    if (scrollFromTop >= 150) {
        jQuery(".custom-header, .mob-header").addClass("scrolled");
    }
    else {
        jQuery(".custom-header, .mob-header").removeClass("scrolled");
    }

    scroll(loop);
}

// Call the loop for the first time
loop();



// HELPER FUNCTIONS TO CHECK ELEMENT VISIBILITY

function isElementPartiallyInViewport(el) {
    //special bonus for those using jQuery
    if (typeof jQuery !== 'undefined' && el instanceof jQuery) el = el[0];

    var rect = el.getBoundingClientRect();
    // DOMRect { x: 8, y: 8, width: 100, height: 100, top: 8, right: 108, bottom: 108, left: 8 }
    var windowHeight = (window.innerHeight || document.documentElement.clientHeight);
    var windowWidth = (window.innerWidth || document.documentElement.clientWidth);

    // http://stackoverflow.com/questions/325933/determine-whether-two-date-ranges-overlap
    var vertInView = (rect.top <= windowHeight) && ((rect.top + rect.height) >= 0);
    var horInView = (rect.left <= windowWidth) && ((rect.left + rect.width) >= 0);

    return (vertInView && horInView);
}




jQuery(".form-submit-btn").click(function() { // class of submit button
	setTimeout(
	function() {
	    jQuery('html,body').animate({
	        scrollTop: jQuery(".wpcf7-response-output").offset().top-380}, //class to scroll
	        'slow');
	}, 3000); // we add time out to make the scroll after some seconds of button click
});
document.addEventListener( 'wpcf7mailsent', function( event ) {
	setTimeout(
   function() {
	   jQuery('html,body').animate({
		   scrollTop: jQuery(".wpcf7-response-output").offset().top-380}, //class to scroll
		   'slow');
   }, 2000);
}, false );



jQuery(document).ready(function(){
	jQuery(".expand-content-text").each(function() {

		var textWrapHeight = jQuery(this).height();
		var maxTextHeight = 300;

		if (textWrapHeight > maxTextHeight ) {
			// console.log(textWrapHeight);
			var readContent = document.getElementById('readML');
		    jQuery(this).addClass('expand');
			readContent = jQuery(this).find("#readML").html("Διαβάστε περισσότερα");

			jQuery(this).find("#readML").click(function() {
				// console.log("click");
				jQuery(this).parent('.expand-content-text').toggleClass("expand");
				if (jQuery(this).parent('.expand-content-text').hasClass("expand")) {
					jQuery(this).html("Διαβάστε περισσότερα");
			   } else {
				 	jQuery(this).html("Διαβάστε λιγότερα");
			   }
			});
		}
	});
 });




