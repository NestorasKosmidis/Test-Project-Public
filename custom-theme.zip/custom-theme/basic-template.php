<?php /* Template Name: Basic-Template */ ?>

<?php get_header(); ?>

<main class="site-content">

    <section class="intro-wrapper">
        
    </section>



</main>

<?php get_footer(); ?>
