<?php /* Custom Header */ ?>

<header class="custom-header">

    <div class="pop_up_offer black_bg show-on-scroll slide-down">
        <span class="pop_up_text"><?php the_field('pop_up_text'); ?></span> 
        <a class="pop_up_button" href="#"><?php the_field('pop_up_button'); ?></a>
        <span class="close-popup icon-x"></span>
    </div>

    <div class="header-center-wrap ">


        <button class="burger-menu">
            <span class="burger-icon"></span>
        </button>


        <?php if ( get_custom_logo() ) : ?>
            <?php the_custom_logo(); ?>
        <?php endif; ?>

        <div class="mobile-icons">
            <a href="#"><span class="icon-search"></span></a>
            <a href="#"><span class="icon-cart"></span></a>
            <a href="#"><span class="icon-account"></span></a>
        </div>

        <div class="header-menu-wrap">
            <?php wp_nav_menu( array( 'theme_location' => 'main-menu' ) ); ?>
        </div>
        <form class="search-form" action="#" method="get">
            <input type="text" class="search-input" placeholder="Search for products...">
            <button type="submit" class="search-button">
                <span class="icon-search"></span>
            </button>
        </form>
        <div class="icons-wrap">
            <a href="#"><span class="icon-cart"></span></a>
            <a href="#"><span class="icon-account"></span></a>
            
        </div>
    </div>
    
    
</header>
