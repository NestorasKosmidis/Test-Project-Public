<?php /* Custom Footer */ ?>


<footer class="custom-footer">
    <div class="footer-wrap">

        <div class="newsletter show-on-scroll slide-up">
            <span class="newsl-text"> <?php the_field('newsletter_text') ?></span>
            <div class="newsl-form">
                <form action="action_page.php">
                    <div class="input">
                        <span class="icon-mail"></span>
                        <input type="text" placeholder="Enter your email address" name="mail" required>
                    </div>
                    <input type="submit" value="Subscribe to Newsletter">
                </form>
            </div>
        </div>

        <div class="footer-top-wrapper">

            <div class="footer-menu-wrapper">
                <div class="footer-menus-wrapper-inner">
                    <div class="footer-menu-wrap logo-wrap">
                        <div class="footer-logo-wrapper show-on-scroll slide-up">
                            <?php if ( get_custom_logo() ) : ?>
                                <?php the_custom_logo(); ?>
                            <?php endif; ?>
                            <span class="company-text"><?php the_field('company_text'); ?></span>
                            <div class="footer-socials-wrap">
                                <a href="<?php the_field('twitter_link') ?>" class="social-btn" target="_blank">
                                    <span class="icon-twitter"></span>
                                </a>
                                <a href="<?php the_field('facebook_link') ?>" class="social-btn" target="_blank">
                                    <span class="icon-facebook"></span>
                                </a>
                                <a href="<?php the_field('instagram_link') ?>" class="social-btn" target="_blank">
                                    <span class="icon-instagram"></span>
                                </a>
                                <a href="<?php the_field('github_link') ?>" class="social-btn" target="_blank">
                                    <span class="icon-github"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="footer-menu-wrap show-on-scroll slide-up">
                        <span class="menu-title"><?php _e('Company','text-lib'); ?></span>
                        <?php wp_nav_menu( array( 'theme_location' => 'company-menu' ) ); ?>
                    </div>
                    <div class="footer-menu-wrap show-on-scroll slide-up">
                        <span class="menu-title"><?php _e('Help','text-lib'); ?></span>
                        <?php wp_nav_menu( array( 'theme_location' => 'help-menu' ) ); ?>
                    </div>
                    <div class="footer-menu-wrap show-on-scroll slide-up">
                        <span class="menu-title"><?php _e('FAQ','text-lib'); ?></span>
                        <?php wp_nav_menu( array( 'theme_location' => 'faq-menu' ) ); ?>
                    </div>
                    <div class="footer-menu-wrap show-on-scroll slide-up">
                        <span class="menu-title"><?php _e('Resources','text-lib'); ?></span>
                        <?php wp_nav_menu( array( 'theme_location' => 'resources-menu' ) ); ?>
                    </div>
                </div>

            </div>

 

        </div>

    </div>

    <div class="footer-bottom-wrap">
        <span class="footer-copyright show-on-scroll slide-up">Shop.co &copy; <?php echo date("Y");?>. All Rights Reserved</span>
        <span class="payment_methods show-on-scroll slide-up">
            <?php $image = get_field('payment_methods');
            if ( !empty($image) ): ?>
                <img class="cards" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
            <?php endif; ?>
        </span>                       
    </div>

</footer>
